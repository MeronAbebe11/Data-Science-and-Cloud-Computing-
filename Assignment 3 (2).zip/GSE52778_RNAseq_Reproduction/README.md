# RNA-Seq Transcriptome Reproduction: GSE52778

## 1. Project Overview

This project reproduces key computational analyses from the study:

**Himes et al. (2014), "RNA-Seq Transcriptome Profiling Identifies CRISPLD2 as a Glucocorticoid Responsive Gene that Modulates Cytokine Function in Airway Smooth Muscle Cells."**

The study investigated gene-expression changes in primary human airway smooth muscle cells following dexamethasone (DEX) treatment.

The main objectives of this reproduction were to:

* understand the original experimental design;
* inspect and process the RNA-seq expression data;
* perform quality-control analysis;
* reproduce differential-expression analysis using DESeq2;
* compare the results with the original Cuffdiff analysis;
* examine important genes reported in the original study, particularly **CRISPLD2**; and
* assess biological and computational reproducibility.

---

## 2. Original Study

### Biological system

* **Organism:** Human
* **Cell type:** Primary human airway smooth muscle cells
* **Number of cell lines:** 4
* **Treatment:** Dexamethasone (DEX)
* **DEX concentration:** 1 μM
* **Treatment duration:** 18 hours
* **Comparison:** DEX-treated vs untreated
* **Sequencing platform:** Illumina HiSeq 2000
* **Read type:** 75-bp paired-end RNA-seq
* **Reference genome:** hg19

The original study used **TopHat 2.0.4, Cufflinks, and Cuffdiff** for RNA-seq analysis.

The original Cuffdiff analysis identified **316 significantly differentially expressed genes at FDR < 0.05**.

---

## 3. Dataset

**GEO accession:** GSE52778

This reproduction focuses on the eight samples corresponding to:

* 4 dexamethasone-treated samples
* 4 untreated samples

The four cell lines were treated as paired biological samples in the DESeq2 analysis.

---

## 4. Data Availability in This Project

The original raw sequencing FASTQ files are **not stored in this project repository** because they are large sequencing files.

The `data/raw/` directory is retained for project organization but is currently empty.

The project uses:

1. A processed FPKM expression matrix from GSE52778.
2. The processed Cuffdiff differential-expression results from the original analysis.
3. The **Bioconductor `airway` dataset**, which contains the corresponding RNA-seq count data and sample metadata used for the DESeq2 analysis.

This allows the main computational reproduction to be performed without storing the large raw FASTQ files locally.

---

## 5. Project Structure

```text
GSE52778_RNAseq_Reproduction/
│
├── data/
│   ├── raw/
│   └── processed/
│       ├── GSE52778_All_Sample_FPKM_Matrix.txt.gz
│       └── GSE52778_Dex_vs_Untreated_gene_exp.diff.gz
│
├── notebooks/
│   ├── GSE52778_RNAseq_Reproduction.ipynb
│   └── DESeq2_analysis.R
│
├── results/
│   ├── figures/
│   └── tables/
│
└── README.md
```

---

## 6. Analysis Workflow

The reproduction followed these main steps:

1. Understand the original study and experimental design.
2. Inspect the GSE52778 expression matrix.
3. Select DEX and untreated samples.
4. Create sample metadata.
5. Convert the expression data from wide to long form
