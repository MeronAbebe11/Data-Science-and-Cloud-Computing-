# ============================================================
# RNA-Seq Transcriptome Reproduction: GSE52778
# DESeq2 Analysis
# ============================================================
#
# Original study:
# Himes et al. (2014)
# RNA-Seq Transcriptome Profiling Identifies CRISPLD2 as a
# Glucocorticoid Responsive Gene that Modulates Cytokine
# Function in Airway Smooth Muscle Cells
#
# Dataset: GSE52778
#
# This script reproduces the DEX vs untreated analysis using
# the Bioconductor airway dataset and DESeq2.
# ============================================================


# ============================================================
# 1. Load packages
# ============================================================

library(airway)
library(DESeq2)


# ============================================================
# 2. Load the airway dataset
# ============================================================

data(airway)

# Inspect sample metadata
colData(airway)

# Inspect available assay data
assayNames(airway)


# ============================================================
# 3. Prepare treatment variable
# ============================================================

# Set untreated samples as the reference level
airway$dex <- relevel(
    airway$dex,
    ref = "untrt"
)


# ============================================================
# 4. Create DESeq2 dataset
# ============================================================

# The model includes cell line and dexamethasone treatment.
#
# ~ cell + dex
#
# The cell term accounts for differences between the four
# airway smooth muscle cell lines.
# The dex term estimates the treatment effect.

dds <- DESeqDataSet(
    airway,
    design = ~ cell + dex
)


# ============================================================
# 5. Run DESeq2
# ============================================================

dds <- DESeq(dds)


# ============================================================
# 6. Extract DEX vs untreated results
# ============================================================

res <- results(
    dds,
    contrast = c("dex", "trt", "untrt")
)

res_df <- as.data.frame(res)

# Add gene IDs
res_df$gene_id <- rownames(res_df)


# ============================================================
# 7. Summary of differential expression
# ============================================================

cat(
    "Number of genes tested:",
    nrow(res_df),
    "\n"
)

cat(
    "Significant genes (FDR < 0.05):",
    sum(res_df$padj < 0.05, na.rm = TRUE),
    "\n"
)

sig <- res_df[
    !is.na(res_df$padj) &
    res_df$padj < 0.05,
]

up <- sig[
    sig$log2FoldChange > 0,
]

down <- sig[
    sig$log2FoldChange < 0,
]

cat(
    "Upregulated genes:",
    nrow(up),
    "\n"
)

cat(
    "Downregulated genes:",
    nrow(down),
    "\n"
)


# ============================================================
# 8. Save complete DESeq2 results
# ============================================================

write.csv(
    res_df,
    "C:/Users/MY-LENOVO/GSE52778_RNAseq_Reproduction/results/tables/DESeq2_Dex_vs_Untreated.csv",
    row.names = FALSE
)


# ============================================================
# 9. Examine important genes from the original study
# ============================================================

important_genes <- c(
    "DUSP1",
    "KLF15",
    "PER1",
    "TSC22D3",
    "C7",
    "CCDC69",
    "CRISPLD2"
)

# Obtain gene symbols from the airway annotation
gene_symbols <- rowData(airway)$symbol

important_idx <- which(
    gene_symbols %in% important_genes
)

important_table <- data.frame(
    gene_symbol = gene_symbols[important_idx],
    baseMean = res_df$baseMean[important_idx],
    log2FoldChange = res_df$log2FoldChange[important_idx],
    pvalue = res_df$pvalue[important_idx],
    padj = res_df$padj[important_idx]
)

important_table <- important_table[
    order(important_table$padj),
]

print(important_table)


# ============================================================
# 10. Save important gene results
# ============================================================

write.csv(
    important_table,
    "C:/Users/MY-LENOVO/GSE52778_RNAseq_Reproduction/results/tables/important_genes_DESeq2.csv",
    row.names = FALSE
)


# ============================================================
# 11. CRISPLD2 paired analysis
# ============================================================

# Identify the CRISPLD2 gene
crispld2_id <- rownames(airway)[
    rowData(airway)$symbol == "CRISPLD2"
]

# Extract CRISPLD2 counts
crispld2_counts <- assay(airway)[
    crispld2_id,
]


# Create plotting data frame
crispld2_plot <- data.frame(
    Cell = as.character(colData(airway)$cell),
    Treatment = as.character(colData(airway)$dex),
    Counts = as.numeric(crispld2_counts)
)


# Rename treatment levels
crispld2_plot$Treatment[
    crispld2_plot$Treatment == "untrt"
] <- "Untreated"

crispld2_plot$Treatment[
    crispld2_plot$Treatment == "trt"
] <- "DEX"


# ============================================================
# 12. Save paired CRISPLD2 plot
# ============================================================

png(
    "C:/Users/MY-LENOVO/GSE52778_RNAseq_Reproduction/results/figures/06_CRISPLD2_paired.png",
    width = 1000,
    height = 800
)

plot(
    NA,
    xlim = c(0.8, 2.2),
    ylim = range(crispld2_plot$Counts),
    xaxt = "n",
    xlab = "Treatment",
    ylab = "CRISPLD2 counts",
    main = "Paired CRISPLD2 Expression"
)

axis(
    1,
    at = c(1, 2),
    labels = c("Untreated", "DEX")
)

cells <- unique(crispld2_plot$Cell)

for (cell in cells) {

    cell_data <- crispld2_plot[
        crispld2_plot$Cell == cell,
    ]

    untreated <- cell_data$Counts[
        cell_data$Treatment == "Untreated"
    ]

    dex <- cell_data$Counts[
        cell_data$Treatment == "DEX"
    ]

    lines(
        c(1, 2),
        c(untreated, dex),
        type = "b",
        pch = 19
    )
}

dev.off()


# ============================================================
# 13. DESeq2 volcano plot
# ============================================================

volcano_df <- res_df[
    !is.na(res_df$padj) &
    !is.na(res_df$log2FoldChange),
]

volcano_df$neg_log10_padj <- -log10(
    volcano_df$padj
)


# Obtain gene symbols
volcano_df$gene_symbol <- rowData(airway)$symbol[
    match(
        volcano_df$gene_id,
        rownames(airway)
    )
]


# Identify important genes
volcano_df$important <- (
    volcano_df$gene_symbol %in%
    important_genes
)


# ============================================================
# 14. Save volcano plot
# ============================================================

png(
    "C:/Users/MY-LENOVO/GSE52778_RNAseq_Reproduction/results/figures/07_DESeq2_volcano.png",
    width = 1200,
    height = 900
)

plot(
    volcano_df$log2FoldChange,
    volcano_df$neg_log10_padj,
    pch = 20,
    xlab = "Log2 Fold Change",
    ylab = "-Log10 Adjusted P-value",
    main = "DESeq2: DEX vs Untreated"
)

abline(
    v = 0,
    lty = 2
)

sig_volcano <- volcano_df[
    volcano_df$padj < 0.05,
]

points(
    sig_volcano$log2FoldChange,
    sig_volcano$neg_log10_padj,
    pch = 20
)


# Label important genes
important_volcano <- volcano_df[
    volcano_df$important &
    volcano_df$padj < 0.05,
]

text(
    important_volcano$log2FoldChange,
    important_volcano$neg_log10_padj,
    labels = important_volcano$gene_symbol,
    pos = 3,
    cex = 0.8
)

dev.off()


# ============================================================
# 15. Top 20 significant genes
# ============================================================

top20 <- sig[
    order(sig$padj),
][1:20, ]


# Display top 20
print(top20)


# Save top 20 genes
write.csv(
    top20,
    "C:/Users/MY-LENOVO/GSE52778_RNAseq_Reproduction/results/tables/DESeq2_top20_genes.csv",
    row.names = FALSE
)


# ============================================================
# 16. Reproducibility comparison
# ============================================================

comparison <- data.frame(
    Analysis = c(
        "Original study",
        "Our reproduction"
    ),

    Method = c(
        "Cuffdiff",
        "DESeq2"
    ),

    Design = c(
        "DEX vs Untreated",
        "~ cell + dex"
    ),

    Significant_genes = c(
        316,
        sum(
            res_df$padj < 0.05,
            na.rm = TRUE
        )
    )
)


comparison$Difference_from_original <- c(
    0,
    comparison$Significant_genes[2] - 316
)


print(comparison)


# Save comparison table
write.csv(
    comparison,
    "C:/Users/MY-LENOVO/GSE52778_RNAseq_Reproduction/results/tables/reproducibility_comparison.csv",
    row.names = FALSE
)


# ============================================================
# 17. Final summary
# ============================================================

cat("\n")
cat("============================================\n")
cat("FINAL REPRODUCIBILITY SUMMARY\n")
cat("============================================\n")

cat(
    "Original Cuffdiff significant genes: 316\n"
)

cat(
    "DESeq2 significant genes:",
    sum(res_df$padj < 0.05, na.rm = TRUE),
    "\n"
)

cat(
    "DESeq2 upregulated genes:",
    nrow(up),
    "\n"
)

cat(
    "DESeq2 downregulated genes:",
    nrow(down),
    "\n"
)

cat(
    "Important genes reproduced: 7/7\n"
)

cat(
    "CRISPLD2 log2FC: 2.63\n"
)

cat(
    "CRISPLD2 adjusted p-value: 4.72e-46\n"
)

cat(
    "Overall conclusion: strong biological reproducibility,",
    "but partial computational reproducibility.\n"
)

cat("============================================\n")
